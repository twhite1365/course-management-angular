import { Component, Attribute, input, output, inject } from "@angular/core";
import { Course } from "../../models/course";
import { CommonModule } from "@angular/common";

@Component({
  selector: "course-card",
  standalone: true,
  imports: [CommonModule],
  templateUrl: "./course-card.component.html",
  styleUrls: ["./course-card.component.css"],
})
export class CourseCardComponent {
  
  course = input.required<Course>();
  cardIndex = input<number>();
  courseChanged = output<Course>();  

  onTitleChanged(newTitle: string) {
    this.course().description = newTitle;
  }

  onSaveClicked(description: string) {
    this.courseChanged.emit({
      ...this.course(),
      description,
    });
  }
  
}
